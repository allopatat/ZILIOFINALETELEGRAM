import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Ziliobot extends TelegramLongPollingBot {
    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {

            Message message = update.getMessage();
            Long chatId = message.getChatId();
            if(message.getText().contains("/") || message.getText().contains("mostra di nuovo scarpe")){

            String url = "https://www.ssense.com/en-it/men/shoes?sort=popularity-desc";
            Scraper scraper = new Scraper();
            List<Product> products;
            try {
                products = scraper.getProducts(url);
                products = sortByPrice(products);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            for (int i = 0; i < Math.min(products.size(), 20); i++) {
                sendTextMessage(chatId, products.get(i).toString());
            }
                sendTextMessage(chatId, "Benvenuto nel BOTlocker di Zilio!, se vuoi maggiori dettagli di una delle scarpe appena mostrate, inserisci il modello esatto della scarpa(copia incolla il nome, case sensitive!!!!) riceverai un link che ti reindirizza al sito dove effettuare le compere!!");
            }
            else {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/scarpe", "root", "");


                    String sql = "SELECT linkalprodotto FROM scarpe WHERE modello = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

                        pstmt.setString(1, message.getText());

                        try (ResultSet rs = pstmt.executeQuery()) {
                            if (rs.next()) {

                                String link = rs.getString("linkalprodotto");
                                sendTextMessage(chatId, link);
                                sendTextMessage(chatId, "per rivedere le altre scarpe scrivi (mostra di nuovo scarpe)");
                            } else {

                                sendTextMessage(chatId, "No link found for the given modello.");
                            }
                        }
                    }

                    conn.close();
                } catch (SQLException e) {

                    System.out.println(e.getMessage());
                }


            }
        }
    }

    private void sendTextMessage(Long chatId, String text) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(text);

        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    public static List<Product> sortByPrice(List<Product> products) {
        return products.stream()
                .sorted((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()))
                .toList();
    }

    @Override
    public String getBotUsername() {
        return "Zilio5CIIbot";
    }

    @Override
    public String getBotToken() {
        return "6494751334:AAHHBPpskUtW9P7otu21X-HfKIhFt3qjZtY";
    }
}