import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.sql.*;

public class Scraper {
    public static List<Product> getProducts(String url) throws IOException {
        Document doc = Jsoup.connect(url).get();
        Elements productTiles = doc.select(".plp-products__product-tile");

        List<Product> products = new ArrayList<>();

        for (Element productTile : productTiles) {
            Element jsonLdScript = productTile.select("script[type=application/ld+json]").first();
            if (jsonLdScript != null) {
                String jsonLdData = jsonLdScript.data();
                String imageUrlRegex = "\"image\":\\s*\"(.*?)\"";
                String imageUrl = RegexUtils.extractGroup(jsonLdData, imageUrlRegex, 1);

                String model = productTile.select("span[data-test^=productName]").text();
                String brand = productTile.select("span[data-test^=productBrandName]").text();
                Double price = Double.valueOf(productTile.select("span[data-test^=productCurrentPrice]").text().replace("€", ""));
                String href = getProductHref(jsonLdData);

                href = "https://www.ssense.com/en-it" + href;

                Product product = new Product(model, price, brand, imageUrl, href);
                products.add(product);

                product.addtoDB();
            }
        }

        return products;
    }

    private static String getProductHref(String jsonLdData) {
        String hrefRegex = "\"url\":\\s*\"(.*?)\"";
        return RegexUtils.extractGroup(jsonLdData, hrefRegex, 1);
    }

    private static Double parsePrice(String priceText) {
        try {
            return Double.parseDouble(priceText.replaceAll("[^\\d.]", ""));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private static String getImageUrl(Element productTile) {
        Element jsonLdScript = productTile.select("script[type=application/ld+json]").first();
        if (jsonLdScript != null) {
            String jsonLdData = jsonLdScript.data();
            String imageUrlRegex = "\"image\":\\s*\"(.*?)\"";
            String imageUrl = RegexUtils.extractGroup(jsonLdData, imageUrlRegex, 1);
            return imageUrl;
        }
        return "";
    }
}



class RegexUtils {
    public static String extractGroup(String input, String regex, int group) {
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
        java.util.regex.Matcher matcher = pattern.matcher(input);
        if (matcher.find() && group <= matcher.groupCount()) {
            return matcher.group(group);
        }
        return "";
    }
}



class Product {
    private String model;
    private Double price;
    private String brand;
    private String imageUrl;
    private String href;


    public Product(String model, Double price, String brand, String imageUrl, String href) {
        this.model = model;
        this.price = price;
        this.brand = brand;
        this.imageUrl = imageUrl;
        this.href = href;
    }


    public String getHref() {
        return this.href;
    }


    public void addtoDB() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/scarpe", "root", "");
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO scarpe (modello,produttore,linkalprodotto) VALUES ('" + this.model + "','" + this.brand + "','" + this.href + "')";
            stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }



    }
    @Override
    public String toString() {
        return "price: " + this.price + "\nmodel: " + this.model + "\nbrand: " + this.brand + "\nimageUrl: " + this.imageUrl;
    }

    public double getPrice() {
        return this.price;
    }

    public String getModel() {
        return this.model;
    }

    public String getBrand() {
        return this.brand;
    }
}

